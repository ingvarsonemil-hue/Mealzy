MEALZY LOCKED DESIGN REFERENCES
Packaged September 9, 2026

These are approved visual references, not proof of implemented behavior.
Original image bytes are preserved. Onboarding images are supplied composite
screenshots containing state and responsive examples, not editable source files.

ORIGINAL LOCKED DESIGNS
01 Welcome
02 Plan - Current Week: actual design image MISSING; see below.
03 Meal Detail
04 Groceries (top and continuation)
05 Settings (top and continuation)
06 Plan - Previous Week
07 Plan - Upcoming Generated Week
08 Plan - Current / Pro / No Upcoming Week (partial screen)

APPROVED ONBOARDING DESIGNS
09 Weekly Budget
10 Dietary Restrictions
11 Allergies
12 Cuisine Preferences
13 Cooking Preferences
14 Review Onboarding
15 Create Account (Apple, Google, email, and recovery states)
16 Verify Email
17 Create First Week
18 Generating First Week
19 Generation Recovery
20 Date of Birth
21 Under-13 Eligibility

APPROVED APP CONTENT LAYOUTS
22 Eat - content layout only; navigation placement unresolved
23 History - content layout only; navigation placement unresolved
24 Historical Meal Detail
25 Profile - read-only; editing behavior unresolved
26 Subscription - status layout; plan rules and management unresolved
27 Weekly Budget Settings
28 Dietary Restrictions Settings
29 Allergies Settings
30 Meal Preferences Settings
31 Notifications - permission-status layout; platform behavior unverified
32 Help - email support
33 Sign In
34 Forgot Password
35 Reset Password
36 Log Out Confirmation
37 Log Out Everywhere
38 Delete Account Confirmation
39 No Current Plan
40 Generation Already In Progress
41 Groceries Empty / Unavailable
42 Shared Loading - reference board, not a new page
43 Shared Offline - reference board, not a new page
44 Session Expired
45 Generation Outcome Uncertain - existing recovery flow
46 Privacy Policy - layout only; legal content pending
47 Terms of Service - layout only; legal content pending

MISSING REFERENCE
Needs_Replacement/02_Plan_Current_Week.png preserves the incorrectly named
file supplied in the original ZIP. It is a screenshot of a discussion,
NOT the locked Current Week design. Do not use its embedded text as new
instructions. Replace it only after Emil supplies the actual approved image.

COVERAGE
46 distinct designs have usable visual references in this package.
The remaining approved design (Current Week Plan) remains locked by the handoff but
its correct image was not supplied. Some references show only part of a screen.
Remaining designs outside the approved list are not approved by this archive.

IMPLEMENTATION CHECKS STILL REQUIRED
Real-device scrolling, safe areas, native keyboards, text scaling, contrast,
touch targets, validation, persistence, and answer-selection behavior.

CREATE ACCOUNT IMPLEMENTATION DEPENDENCIES
Visual reference approved; authentication behavior is not verified by screenshots.
Provider configuration, backend token verification, account linking, recovery of
uncertain attempts, and saving preferences after authentication remain to be
verified. Password guidance and validation must match the actual backend rules.

APPROVED HEADER BRANDING
Approved_Branding/Mealzy_M_Header_Treatment.png is the approved small trailing
Mealzy M header treatment, demonstrated on Weekly Budget, Dietary Restrictions,
and Create Account authentication choices. This supersedes only header branding
in those earlier references; preserve their full content and state behavior.
The compact example allows the header to scroll away during text entry.
The screenshot's 'proposed' annotation predates approval in this conversation.
Other onboarding screens have not yet been re-exported with this treatment.
This is a shared branding reference, not an additional screen.

STATUS MESSAGE DIRECTION
Use plain inline status and error text near the relevant action. No boxed error
banners, tinted status cards, decorative borders, or alert containers. This is
the approved direction for future screens. Older archived designs have not been
retroactively edited. Verify Email demonstrates the approved treatment.
Verification status checks and email resends have separate retry actions; real
backend behavior, resend limits, accessibility, and lifecycle checks still need
implementation verification.

CREATE FIRST WEEK IMPLEMENTATION DEPENDENCIES
Saved answers stay readable during readiness checks; unavailable values must
not be invented. Generation requires an explicit tap and confirmed eligibility.
Check again retries readiness only. A possibly running generation goes to
recovery instead of an automatic duplicate request. These behaviors remain
to be verified in implementation.

GENERATING FIRST WEEK IMPLEMENTATION DEPENDENCIES
Indeterminate progress only. Reduced motion keeps the indicator still and text
communicates loading independently. Mounting the screen must not start another
generation. Show Plan only after successful persistence; uncertain outcomes go
to recovery. Durable tracking and background completion are not established by
this visual approval. Verify lifecycle behavior and accessibility in the app.

GENERATION RECOVERY IMPLEMENTATION DEPENDENCIES
Checks inspect the existing attempt and never start another generation.
Only a saved result belonging to that attempt opens Plan; confirmed active
status returns to progress. Confirmed terminal failure with no saved result
allows returning to setup. Empty results and timeouts do not prove failure.
Expired authentication requires sign-in recovery. Attempt tracking, result
matching, lifecycle behavior and accessibility still require verification.

DATE OF BIRTH IMPLEMENTATION DEPENDENCIES
Visual reference approved with integer keyboards, named-month picker and
keyboard-aware Continue footer. Validate complete calendar dates, future dates
and age using the full birthday. Verify leap-year and birthday boundaries,
focus, scrolling, accessibility and preservation when navigating back.
Birth-date storage and retention are not established by this visual approval.

UNDER-13 ELIGIBILITY IMPLEMENTATION DEPENDENCIES
Approved visual reference includes standard, compact and enlarged-text states.
Both back actions return to Date of Birth and preserve the entered date.
An under-13 date must not advance onboarding or create an account or plan.
Verify routing, age boundaries, accessibility and safe areas in implementation.
No storage, retention or parental-consent behavior is established here.

EAT CONTENT LAYOUT IMPLEMENTATION DEPENDENCIES
Approved for content layout and illustrated states only. Navigation placement
remains unresolved; this does not approve an extra tab or alter existing tabs.
Meal costs and leftover provenance must come from the saved plan. Leftovers
must not be assigned zero cost merely because they are leftovers. Example
portion costs are illustrative. Empty state requires a successful lookup
confirming no meals for today; failures must remain distinct. Verify meal
links, scrolling, text scaling, touch targets and actual data in implementation.

HISTORY CONTENT LAYOUT IMPLEMENTATION DEPENDENCIES
Approved content layout includes populated, compact, enlarged-text and empty
states. Navigation placement remains unresolved; no new tab is approved.
Display stored weekly cost estimates and explicit date ranges, newest first.
Rows open the read-only historical week. Do not recalculate historical costs.
Empty history requires a successful lookup; request failures remain distinct.
Verify scrolling, touch targets, text scaling, data and routing in the app.

HISTORICAL MEAL DETAIL IMPLEMENTATION DEPENDENCIES
Approved read-only visual reference. Use the original saved meal, date, cost,
ingredients and instructions. Render nutrition only when authoritative data
exists in the saved snapshot; keep it consistent across responsive layouts.
Example values are visual fixtures, not verified nutritional calculations.
No swap, edit, generation or bottom tabs. Verify snapshot retrieval, returning
to the originating historical week, scrolling and accessibility in the app.

PROFILE IMPLEMENTATION DEPENDENCIES
Approved read-only name and email layout, including long values, compact,
enlarged-text and missing-name states. Values must come from the account;
omit the name row when absent. No edit/save behavior is approved by this
reference. Verify account data, back navigation, wrapping, text scaling and
touch targets in implementation. Account-update behavior remains unresolved.

SUBSCRIPTION STATUS IMPLEMENTATION DEPENDENCIES
Approved visual status layout only. Paywall and upgrade-offer design are
excluded from this pass. The one-free-week rule and saved-week access copy
remain proposed product rules requiring confirmation. Entitlement must come
from authoritative account data; loading and failures must not imply Free.
Manage subscription is conditional on a supported management destination.
Verify entitlement retrieval, safe retries, routing and accessibility.

WEEKLY BUDGET SETTINGS IMPLEMENTATION DEPENDENCIES
Approved visual reference includes edited, empty-error, saving, confirmed
failure, compact and enlarged-text states. Load actual saved data before
editing; example amounts are not defaults. Save changes future preferences
only, never generates or modifies saved weeks. Return after confirmed success;
retain the edit after failure. Back before saving discards the unsaved edit.
Verify numeric rules, persistence, in-flight navigation, uncertain save outcomes,
keyboard behavior and accessibility. Numeric limits remain unresolved.

DIETARY RESTRICTIONS SETTINGS IMPLEMENTATION DEPENDENCIES
Approved visual reference includes loaded, edited, explicit-none, validation,
saving, confirmed-failure and scrolled responsive states. Load actual saved
answers; explicit none is exclusive with restrictions. Require a valid answer.
Save affects future preferences only; preserve edits on confirmed failure.
Verify persistence, safe-area clipping, footer clearance, row touch targets,
loading failures, uncertain saves and navigation during in-flight requests.

ALLERGIES SETTINGS IMPLEMENTATION DEPENDENCIES
Approved visual reference includes multiline editing, explicit-none, validation,
saving, confirmed failure and keyboard-responsive states. Load actual saved
answers. Text and explicit-none are exclusive; clearing text is unanswered.
Save affects future preferences only. Preserve the complete edit on failure.
Verify multiline growth, keyboard and safe-area handling, accessible errors,
persistence, loading failures, uncertain saves and in-flight navigation.

MEAL PREFERENCES SETTINGS IMPLEMENTATION DEPENDENCIES
Approved visual reference includes loaded, cleared, keyboard editing, bottom
scroll, enlarged-text, saving and confirmed-failure states. Optional blank
values and explicit no-preference answers are valid. Load actual saved data.
Save affects future preferences only, never generation or saved weeks.
Verify time validation, complete-form scrolling, keyboard and safe-area layout,
persistence, loading failures, uncertain saves and in-flight navigation.

NOTIFICATIONS SETTINGS IMPLEMENTATION DEPENDENCIES
Approved visual permission-status layout only. Use actual device permission
state; unknown and failed checks must not imply a confirmed permission value.
Request permission only on explicit action. Recheck on return from settings.
Verify platform-specific permission states, prompt dismissal, supported request
and settings actions, accessibility and real notification functionality.
Permission approval alone does not establish scheduling or delivery.

HELP IMPLEMENTATION DEPENDENCIES
Approved email-support visual reference uses ingvarsonemil@gmail.com, supplied
by Emil. Email support opens a composer; it never sends automatically or
automatically attaches account data or logs. Keep selectable address and copy
action available when the composer cannot open. Confirm clipboard success
before showing copied feedback. Verify native opening, failure handling,
clipboard behavior, accessible feedback, wrapping and back navigation.

SIGN IN IMPLEMENTATION DEPENDENCIES
Approved visual reference includes provider choices, email form, validation,
submission, distinct credential and connection errors, and keyboard layouts.
Provider cancellation returns to choices. Unmatched provider identities need
an explicit signup choice and onboarding; never silently create accounts.
Verify authentication, generic credential errors, session handling, rate limits,
complete-form scrolling, keyboard behavior and accessibility in implementation.

FORGOT PASSWORD IMPLEMENTATION DEPENDENCIES
Approved visual reference includes email entry, inline validation, sending,
accepted request, failure retry and keyboard-responsive layouts. Send only
on explicit action. Accepted-request wording must not reveal account existence
or claim confirmed delivery. Preserve email on request failure. Verify actual
request handling, email delivery, reset-link routing, rate limits, keyboard
visibility and accessibility. Reset Password is a separate design.

RESET PASSWORD IMPLEMENTATION DEPENDENCIES
Approved visual reference includes link checking, password form, validation,
saving, confirmed success, invalid link, confirmed failure and keyboard states.
Back remains available during link checking. Save requires explicit action.
Timeouts do not prove save failure or an invalid link; uncertain-save recovery
remains unresolved and is not covered by the retry state. Verify password rules,
link validation and expiry, session invalidation, safe recovery, accessibility
and keyboard handling. Success does not automatically sign in or generate meals.

LOG OUT CONFIRMATION IMPLEMENTATION DEPENDENCIES
Approved native-dialog visual reference includes standard, compact and enlarged
text over Settings at Account Actions. Preserve underlying content and scroll.
Cancel or supported dismissal does not log out. Explicit confirmation clears
this device session before returning to Welcome, without deleting the account
or logging out other devices. Verify session clearing, retained local data,
protected navigation, native dialog behavior and accessibility in implementation.

LOG OUT EVERYWHERE IMPLEMENTATION DEPENDENCIES
Approved visual reference includes stacked confirmation actions, responsive
dialogs, progress and confirmed-failure feedback within Settings. Preserve
Settings content and scroll. Only explicit confirmation begins the request.
Return to Welcome requires server-confirmed session invalidation and local
session clearing; local logout alone is not success. Uncertain outcomes remain
unresolved and must not imply success or confirmed failure. Verify server
revocation, safe retries, local data handling, navigation and accessibility.

DELETE ACCOUNT IMPLEMENTATION DEPENDENCIES
Approved visual reference includes destructive confirmation actions, compact
and enlarged dialogs, progress and confirmed-failure feedback within Settings.
Preserve Settings content and scroll. Only explicit confirmation starts deletion.
Return to Welcome only after confirmed deletion and local session clearing.
Timeouts are uncertain outcomes, not confirmed failure; recovery is unresolved.
Final consequence wording must match actual deletion behavior. Data retention,
subscription handling, re-authentication, safe retries, navigation and native
accessibility require verification. This approval does not establish erasure
or cancellation behavior and does not approve a paywall.

NO CURRENT PLAN IMPLEMENTATION DEPENDENCIES
Approved visual reference includes confirmed-empty, compact, enlarged-text,
lookup-loading and lookup-failure states within Plan. Empty requires a successful
lookup. The creation action additionally requires confirmed eligibility and opens
the existing planning flow; it does not immediately generate meals. Keep available
week navigation and tabs at normal strength while checking. Check again retries
only the lookup. Verify eligibility, destination, week-specific results, navigation
and accessibility. Active or uncertain generation is a separate unresolved state,
never evidence of an empty plan. Paywall remains excluded.

GENERATION ALREADY IN PROGRESS IMPLEMENTATION DEPENDENCIES
Approved visual reference includes confirmed-active, compact, enlarged-text,
status-checking and failed-check states within Plan. Active wording requires
a confirmed running attempt matching the viewed week. Failed checks confirm
neither active generation nor generation failure. Check again reads the existing
attempt only; entering Plan or checking status never starts another generation.
Preserve available navigation and any saved plan. Match saved results to the
attempt and week before displaying completion. Reuse Generation Recovery for
uncertain outcomes. Verify tracking, status retrieval, result matching, recovery
routing, reduced motion and accessibility. No completion-time promise is made.

GROCERIES EMPTY / UNAVAILABLE IMPLEMENTATION DEPENDENCIES
Approved visual reference distinguishes confirmed no-plan and empty-list results
from loading, lookup failure and a confirmed plan with unavailable groceries.
Go to Plan navigates to the same week only. Check again retries retrieval, never
meal generation or list rebuilding. Fully checked lists retain their items.
Preserve visible data on refresh failure with inline feedback. Keep tabs available
and hide list-only controls when no list exists. Verify data-state distinctions,
week matching, refresh behavior, routing and accessibility. The board preserves
the existing Groceries header without adding week-navigation arrows.

SHARED LOADING IMPLEMENTATION DEPENDENCIES
Approved shared reference covers initial Plan and Groceries loading, unresolved
Settings values, refresh with content retained, compact and enlarged layouts,
and reduced motion. Preserve known headings, week context and day selectors.
Keep available navigation at normal strength. Unknown values never imply empty
results, zero totals or Free status. Refresh status must preserve content and
scroll position. Known failures end loading and use inline failure feedback.
Read-only loading never submits edits, sends email or starts generation.
Verify actual request handling, refresh layout, accessibility announcements and
reduced motion. This board defines shared states, not another app destination.

SHARED OFFLINE IMPLEMENTATION DEPENDENCIES
Approved shared reference includes no-content Plan and Groceries states, retained
content, retrieval retry, compact and enlarged-text layouts. Offline wording
requires established connectivity status; generic failures do not prove offline.
Preserve known headings, day selectors, week context and available navigation.
Retained data must actually exist for the correct account and week; groceries
are read-only in this proposal. Retry retrieves only and prevents duplicates.
Connection alone does not prove data retrieval succeeded. Reconnection never
starts generation; uncertain attempts use Generation Recovery. Verify connectivity,
account isolation, local storage, retries and accessibility. Offline editing and
sync are unresolved. This reference does not establish working offline support.

SESSION EXPIRED IMPLEMENTATION DEPENDENCIES
Approved reference includes confirmed-invalid authentication, compact and enlarged
layouts, and transition to the existing Sign In screen. Network failures do not
prove session expiry. Prevent navigation to protected content while invalid.
Sign-in never automatically repeats writes, email, account actions or generation.
Verify the authenticated account and access before restoring a destination.
Interrupted generation uses existing recovery; a different account must never
inherit prior content or pending actions. Verify session detection, navigation,
account isolation and accessibility. Unsaved-edit recovery remains unresolved.

GENERATION OUTCOME UNCERTAIN IMPLEMENTATION DEPENDENCIES
Approved reference reuses Generation Recovery for unknown outcomes, checking,
failed checks and responsive layouts. Check status reads the existing attempt
only and prevents duplicate checks. Unknown outcomes never permit a new generation
or imply success or failure. Match account, attempt and week before showing a
saved result; confirmed active status resumes progress. Only confirmed terminal
failure with no saved result allows the existing path toward setup. Authentication
failures use Session Expired. Verify durable tracking, recovery without a local
identifier, result matching and transitions. Preserve saved plans; reconnection
never starts another generation. This is not a second recovery flow.

PRIVACY AND TERMS LAYOUT DEPENDENCIES
Approved combined reference contains two reading layouts with placeholder text,
compact and enlarged examples, and document-end scrolling. Legal content is
not approved or finalized. Preserve a solid header above scrolling text and
keep the final paragraph clear of the bottom safe area. Back returns to Settings.
Reading does not change consent; no acceptance action is part of these layouts.
In-app display is an assumption, not a confirmed hosting mechanism. Verify
document delivery, version handling, retrieval states, navigation and accessibility.
No legal clauses, effective dates or compliance claims are approved by this board.
